angular.module('trail').controller('contentCtrl', function($scope, $ionicScrollDelegate){

});