// angular.module('trail').controller('infoCtrl', function($scope){
//     $scope.test = 'This is working!';
// $scope.go = function(path){
//     $location.path(path);
// };
// });